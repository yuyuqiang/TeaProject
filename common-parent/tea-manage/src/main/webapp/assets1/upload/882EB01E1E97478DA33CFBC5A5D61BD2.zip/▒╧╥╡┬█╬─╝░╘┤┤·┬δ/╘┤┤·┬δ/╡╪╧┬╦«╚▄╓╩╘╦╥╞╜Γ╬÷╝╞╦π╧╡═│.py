from tkinter import *
from pylab import mpl
import matplotlib.pyplot as plt
from matplotlib import colors
import numpy as np
import webbrowser,math
from scipy import optimize, special
from PIL import ImageTk, Image
from scipy.integrate import quad,dblquad,nquad

def ct():
    global frame
    frame.pack_forget()
    frame = Frame(root, width=900, height=800)
    frame.pack(side=LEFT)
    canvas = Canvas(frame, width=900, height=800)
    image = Image  .open("1.jpg")
    im = ImageTk.PhotoImage(image)

    canvas.create_image(350,220, image=im)
    canvas.create_text(450, 180,
                       text='地下水溶质运移计算'
                       , fill='white'
                       ,font=("华文楷体", 30, 'bold'))
    canvas.pack()
    root.mainloop()

def ct1():
    global frame
    frame.pack_forget()
    frame = Frame(root, width=900, height=800)
    frame.pack(side=LEFT)

    text = Text(frame, width=130, height=46)
    text.place(x = 0, y = 0)
    text.tag_add("link", "1.0", "1.5")
    text.tag_config("link", font=("华文楷体", 14, 'bold'))
    text.tag_config("link1", foreground="blue", underline=True)
    text.tag_config("link1", font=("华文楷体", 14, 'bold'))
    text.tag_config("link2", font=("华文楷体", 14, 'bold'))
    text.insert(INSERT, " \n           本程序为", "link")
    text.insert(INSERT, "  《环境影响评价技术导则——地下水环境》", "link1")
    text.insert(INSERT, "  (HJ 610-2016)，附录D 常用地下水"
                        "\n\n     预测模型中地下水溶质运移解析法的简易计算程序。"
                        "\n\n          应用条件："
                        "\n\n          求解复杂的水动力弥散方程定解问题非常困难，实际问题中多"
                        "靠数值方法求解。但可以用\n\n    解析解对照数值解法进行检验和比较，"
                        "并用解析解去拟合观测资料以求得水动力弥散系数。"
                        "\n\n           其中，地下水溶质运移解析法有两种模式："
                        "\n\n            一维模式："
                        "\n\n           一维无线长多孔介质柱体，示踪剂瞬时注入；"
                        "\n\n           一维半无线长多孔介质柱体，一端为定浓度边界。"
                        "\n\n           二维模式："
                        "\n\n           瞬时注入示踪剂——平面瞬时点源；"
                        "\n\n           连续注入示踪剂——平面连续点源 。","link2")

    def show_arrow_cursor(event):
        text.config(cursor="arrow")

    def show_xterm_cursor(event):
        text.config(cursor="xterm")

    def click(event):
        webbrowser.open("http://www.china-eia.com/")

    text.tag_bind("link1", "<Enter>", show_arrow_cursor)
    text.tag_bind("link1", "<Leave>", show_xterm_cursor)
    text.tag_bind("link1", "<Button-1>", click)


def ct2():
    global frame
    frame.pack_forget()
    frame = Frame(root, width=900, height=800)
    frame.pack(side=LEFT)

    text = Text(frame, width=130, height=46)
    text.place(x = 0, y = 0)
    text.tag_config("link", font=("华文楷体", 14, 'bold'))
    text.insert(INSERT, " \n                             "
                        "               一维稳定流动一维水动力弥散问题"
                        "\n\n               一维无限长多孔介质柱体，示踪剂瞬时注入:"
                        "\n\n\t\t\t\t\t", "link")

    text.image_create(INSERT,  image=photo1)
    text.insert(INSERT,"\n\n              式中：x ——距注入点的距离，m；"
                       "\n\n                        t ——时间，d；"
                       "\n\n                        C(x,t)——t 时刻 x 处的示踪剂质量浓度，g/L；"
                       "\n\n                        m ——注入的示踪剂质量，kg；"
                       "\n\n                        w ——横截面面积，m2"
                       "\n\n                        u ——水流速度，m/d；"
                       "\n\n                        ne——有效孔隙度，量纲为 1；"
                       "\n\n                        DL——纵向弥散系数，m2/d；"
                       "\n\n                        π ——圆周率。","link")





def ct3():
    def Calculation():
        t.delete("1.0", END)
        m = float(v1.get())
        w = float(v2.get())
        u = float(v4.get())
        ne = float(v5.get())
        Dl = float(v3.get())
        t1 = float(w1.get())
        Xmax = float(w2.get())
        X = float(w3.get())
        x2 = float(w4.get())
        Tmax = float(w5.get())
        t2 = float(w6.get())

        if (var.get()) == 1:
            L = list(np.arange(0, Xmax, X))
            t.tag_config("link2", font=("微软雅黑", 12, 'bold'), justify=LEFT)
            t.insert("insert", "固定时间，不同位置预测的结果为：\n", "link2")
            t.insert("insert", "预测距离(m)" + "\t\t  " + '   '  +  "污染物浓度(g/l) " + '\n', "link2")
            for x1 in L:
                X = []
                Y = []
                C1 = ((m / w) / (2 * ne * math.sqrt(np.pi * Dl * t1))) * (
                        2.718281828459 ** (-1 * (((x1 - u * t1) ** 2)) / (4 * Dl * t1)))
                X.append(x1)
                Y.append(C1)
                t.insert('insert', ('   ' + str(X[0]) + "\t\t" + str(Y[0])+ '\r\n'), "link2")

        if (var.get()) == 2:
            L1 = list(np.arange(t2, Tmax, t2))
            t.tag_config("link2", font=("微软雅黑", 12, 'bold'), justify=LEFT)
            t.insert("insert", "固定位置，不同时间预测的结果为：\n", "link2")
            t.insert("insert", "预测时间(d)" + "\t\t" + '   ' + "污染物浓度(g/l) " + '\n', "link2")
            for t3 in L1:
                X1 = []
                Y1 = []
                C2 = ((m / w) / (2 * ne * math.sqrt(np.pi * Dl * t3))) * (
                        2.718281828459 ** (-1 * (((x2 - u * t3) ** 2)) / (4 * Dl * t3)))
                X1.append(t3)
                Y1.append(C2)
                t.insert('insert', ('   ' + str(X1[0]) + "\t\t" + str(Y1[0]) + '\r\n'), "link2")
        else:
            pass

    def Drawing():

        m = float(v1.get())
        w = float(v2.get())
        u = float(v4.get())
        ne = float(v5.get())
        Dl = float(v3.get())
        t1 = float(w1.get())
        Xmax = float(w2.get())
        x3 = float(w3.get())
        x2 = float(w4.get())
        Tmax = float(w5.get())
        t2 = float(w6.get())

        if (var.get()) == 1:
            L = np.arange(0, Xmax)
            X = []
            Y = []

            for x1 in L:
                C1 = ((m / w) / (2 * ne * math.sqrt(np.pi * Dl * t1))) * (
                        2.718281828459 ** (-1 * (((x1 - u * t1) ** 2)) / (4 * Dl * t1)))

                X.append(x1)
                Y.append(C1)


            plt.plot(X, Y, "m", linewidth=1.5)
            plt.xlim(0, Xmax)
            plt.ylim(0, max(Y))
            plt.xticks(np.linspace(0, Xmax, Xmax / x3 + 1, endpoint=True))
            plt.title("瞬时注入，距离--浓度关系图 \nT = " + str(t1) + ' 天')
            plt.xlabel("X-距离  (m)")
            plt.ylabel("C-浓度 (g/L)")
            mpl.rcParams['font.sans-serif'] = ['SimHei']
            mpl.rcParams['axes.unicode_minus'] = False
            plt.show()
        elif (var.get()) == 2:
            X = []
            Y = []


            L = list(np.arange(0.00000000000000001, Tmax))
            for t3 in L:
                C2 = ((m / w) / (2 * ne * math.sqrt(np.pi * Dl * t3))) * (
                        2.718281828459 ** (-1 * (((x2 - u * t3) ** 2)) / (4 * Dl * t3)))

                X.append(t3)
                Y.append(C2)


            plt.plot(X, Y, "c", linewidth=1.5)
            plt.xlim(0, Tmax)
            plt.ylim(0, max(Y))
            plt.xticks(np.linspace(0, Tmax, Tmax / x3 + 1, endpoint=True))
            plt.title("瞬时注入，时间--浓度关系图 \nX = " + str(x2) + ' (m)')
            plt.xlabel("T-时间 (d)")
            plt.ylabel("C-浓度 (g/L)")
            mpl.rcParams['font.sans-serif'] = ['SimHei']
            mpl.rcParams['axes.unicode_minus'] = False
            plt.show()
        else:
            pass

    global frame
    frame.pack_forget()
    frame = Frame(root,width=900, height=800)
    frame.pack(side = LEFT)

    label = Label(frame,
                  text="地下水溶质运移计算",
                  bg="black",
                  fg="white",
                  font=("华文楷体", 18, 'bold'),
                  width=65)

    label.place(x=0, y=0, height=40)

    group3 = LabelFrame(frame,
                        text="一维稳定流动一维水动力弥散问题/"
                             "一维无线长多孔介质柱体，示踪剂瞬时注入",
                        font=("华文楷体", 15, 'bold'))
    group3.place(x=30, y=50, width=850, height=520)

    # 组件“参数设置”
    group4 = LabelFrame(group3, text="参数设置", font=("华文楷体", 12, 'bold'))
    group4.place(x=20, y=10, width=400, height=200)

    v1 = StringVar()
    v2 = StringVar()
    v3 = StringVar()
    v4 = StringVar()
    v5 = StringVar()
    v1.set(200)
    v2.set(100)
    v3.set(10)
    v4.set(1)
    v5.set(0.5)
    Label(group4, text="示踪剂质量(kg) ").grid(row=0, column=0, padx = 5,pady=15)
    Label(group4, text="横截面面积(m2) ").grid(row=0, column=1, padx = 5)
    Label(group4, text="纵向弥散系数(m2/d)").grid(row=0, column=2, padx = 5)
    Entry(group4, textvariable=v1, width=15).grid(row=1, column=0, padx = 5)
    Entry(group4, textvariable=v2, width=15).grid(row=1, column=1, padx = 5)
    Entry(group4, textvariable=v3, width=15).grid(row=1, column=2, padx = 5)
    Label(group4, text="水流速度(m/d) ").grid(row=2, column=0, pady=12)
    Label(group4, text="有效孔隙度(量纲为1) ").grid(row=2, column=1)
    Entry(group4, textvariable=v4, width=15).grid(row=3, column=0)
    Entry(group4, textvariable=v5, width=15).grid(row=3, column=1)


    # 组件“选择方案”
    group5 = LabelFrame(group3, text="选择方案", font=("华文楷体", 12, 'bold'))
    group5.place(x=430, y=10, width=400, height=200)

    var = IntVar()
    w1 = StringVar()
    w2 = StringVar()
    w3 = StringVar()
    w4 = StringVar()
    w5 = StringVar()
    w6 = StringVar()
    w1.set(50)
    w2.set(100)
    w3.set(10)
    w4.set(50)
    w5.set(100)
    w6.set(10)

    r = Radiobutton(group5, text="方案一：固定时间，不同位置预测",variable=var, value=1)
    r.grid(row=0, column=0, columnspan=2)
    Label(group5, text="预测时间,(d) ", ).grid(row=1, column=0,padx = 10)
    Label(group5, text="最远距离,(m) ").grid(row=1, column=1,padx = 10 )
    Label(group5, text="距离间距，(m) ").grid(row=1, column=2,padx = 10 )
    Entry(group5, textvariable=w1, width=15).grid(row=2, column=0, padx=10,)
    Entry(group5, textvariable=w2, width=15).grid(row=2, column=1, padx=10)
    Entry(group5, textvariable=w3, width=15).grid(row=2, column=2, padx=10)
    Radiobutton(group5, text="方案二：固定位置，不同时间预测",variable=var, value=2).grid(row=3, column=0, columnspan=2)
    Label(group5, text="预测距离,(m) ").grid(row=4, column=0, )
    Label(group5, text="最大时间,(d) ").grid(row=4, column=1)
    Label(group5, text="时间间隔,(d) ").grid(row=4, column=2)
    Entry(group5, textvariable=w4, width=15).grid(row=5, column=0)
    Entry(group5, textvariable=w5, width=15).grid(row=5, column=1)
    Entry(group5, textvariable=w6, width=15).grid(row=5, column=2)

    # 组件“预测结果”

    group6 = LabelFrame(group3, text="预测结果",font=("华文楷体", 12, 'bold'))
    group6.place(x=20, y=220, width=810, height=220)
    t = Text(group6, width=110 )

    S1 = Scrollbar(group6)
    S1.pack(side=RIGHT, fill=Y)
    t.pack(side=LEFT, fill=Y)
    S1.config(command=t.yview)
    t.config(yscrollcommand=S1.set)

    Button(group3, text="计算结果", command=Calculation,font=("华文楷体", 12, 'bold')).place(x=120, y=450)
    Button(group3, text="图形显示", command=Drawing, font=("华文楷体", 12, 'bold')).place(x=570, y=450)



def ct4():
    global frame
    frame.pack_forget()
    frame = Frame(root, width=900, height=800)
    frame.pack(side=LEFT)

    text = Text(frame, width=130, height=46)
    text.place(x=0, y=0)
    text.tag_config("link", font=("华文楷体", 14, 'bold'))
    text.insert(INSERT, " \n                             "
                        "               一维稳定流动一维水动力弥散问题"
                        "\n\n               一维半无限长多孔介质柱体，一端为定浓度边界:"
                        "\n\n\t\t\t\t\t", "link")

    text.image_create(INSERT, image=photo5)
    text.insert(INSERT, "\n\n              式中：x ——距注入点的距离，m；"
                        "\n\n                        t ——时间，d；"
                        "\n\n                        C(x,t)——t 时刻 x 处的示踪剂质量浓度，g/L；"
                        "\n\n                        C0——注入的示踪剂浓度，g/L；"
                        "\n\n                        DL——纵向弥散系数，m2/d；"
                        "\n\n                        u ——水流速度，m/d；"
                        "\n\n                        erfc（）——余误差函数。", "link")


def ct5():
    def Calculation():
        t.delete("1.0", END)
        C = float(v1.get())
        DL = float(v2.get())
        u = float(v3.get())
        t1 = float(w1.get())
        Xmax = float(w2.get())
        dx = float(w3.get())
        x2 = float(w4.get())
        Tmax = float(w5.get())
        dt = float(w6.get())
        if (var.get()) == 1:
            L = list(np.arange(0, Xmax, dx ))
            t.tag_config("link2", font=("微软雅黑", 12, 'bold'), justify=LEFT)
            t.insert("insert", "固定时间，不同位置预测的结果为：\n", "link2")
            t.insert("insert", "预测距离(m)"+ "\t\t"+ '   '  + "污染物浓度(g/l) " + '\n', "link2")
            for x1 in L:
                X = []
                Y = []
                a = math.erfc((x1-u*t1)/(2*(math.sqrt(DL*t1))))
                b = math.erfc((x1+u*t1)/(2*(math.sqrt(DL*t1))))
                c = (1/2)*(2.718281828459**((u*x1)/(DL)))
                C1 = C*(((1/2)*a)+(c*b))
                X.append(x1)
                Y.append(C1)
                t.insert('insert', ('  ' + str(X[0]) + "\t\t" + str(Y[0])+ '\r\n'), "link2")

        if (var.get()) == 2:
            L1 = list(np.arange(dt, Tmax, dt))
            t.tag_config("link2", font=("微软雅黑", 12, 'bold'), justify=LEFT)
            t.insert("insert", "固定位置，不同时间预测的结果为：\n", "link2")
            t.insert("insert", "预测时间(d)" + "\t\t" + '   '  +  "污染物浓度(g/l) " + '\n', "link2")
            for t2 in L1:
                X = []
                Y = []
                a = math.erfc((x2 - u * t2) / (2 * (math.sqrt(DL * t2))))
                b = math.erfc((x2 + u * t2) / (2 * (math.sqrt(DL * t2))))
                c = (1 / 2) * (2.718281828459 ** ((u * x2) / (DL)))
                C2 = C * (((1 / 2) * a) + (c * b))
                X.append(t2)
                Y.append(C2)
                t.insert('insert', ('  ' + str(X[0]) + "\t\t" + str(Y[0]) + '\r\n'), "link2")

    def Drawing():
        C = float(v1.get())
        DL = float(v2.get())
        u = float(v3.get())
        t1 = float(w1.get())
        Xmax = float(w2.get())
        dx = float(w3.get())
        x2 = float(w4.get())
        Tmax = float(w5.get())
        dt = float(w6.get())
        if (var.get()) == 1:
            L = np.arange(0, Xmax)
            X = []
            Y = []
            for x1 in L:
                a = math.erfc((x1 - u * t1) / (2 * (math.sqrt(DL * t1))))
                b = math.erfc((x1 + u * t1) / (2 * (math.sqrt(DL * t1))))
                c = (1 / 2) * (2.718281828459 ** ((u * x1) / (DL)))
                C1 = C * (((1 / 2) * a) + (c * b))
                X.append(x1)
                Y.append(C1)
            plt.plot(X, Y, "r--", linewidth=1.5)
            plt.xlim(0, Xmax)
            plt.ylim(0, max(Y))
            plt.xticks(np.linspace(0, Xmax, Xmax / dx + 1, endpoint=True))
            plt.title("定浓度边界，距离--浓度关系图\nT =" +str(t1) +" 天")
            plt.xlabel("X-距离")
            plt.ylabel("C-浓度")
            mpl.rcParams['font.sans-serif'] = ['SimHei']
            mpl.rcParams['axes.unicode_minus'] = False
            plt.show()

        if (var.get()) == 2:
            X = []
            Y = []
            L = list(np.arange(0.00000000000000001, Tmax))
            for t2 in L:
                a = math.erfc((x2 - u * t2) / (2 * (math.sqrt(DL * t2))))
                b = math.erfc((x2 + u * t2) / (2 * (math.sqrt(DL * t2))))
                c = (1 / 2) * (2.718281828459 ** ((u * x2) / (DL)))
                C2 = C * (((1 / 2) * a) + (c * b))
                X.append(t2)
                Y.append(C2)
            plt.plot(X, Y, "y*-", linewidth=1.5)
            plt.xlim(0, Tmax)
            plt.ylim(0, max(Y))
            plt.xticks(np.linspace(0, Tmax, Tmax / dt + 1, endpoint=True))
            plt.title("定浓度边界，时间--浓度关系图\nX =" +str(x2) +" m")
            plt.xlabel("T-时间")
            plt.ylabel("C-浓度")
            mpl.rcParams['font.sans-serif'] = ['SimHei']
            mpl.rcParams['axes.unicode_minus'] = False
            plt.show()

    global frame
    frame.pack_forget()
    frame = Frame(root, width=900, height=800)
    frame.pack(side=LEFT)

    label = Label(frame,
                  text="地下水溶质运移计算",
                  bg="black",
                  fg="white",
                  font=("华文楷体", 18, 'bold'),
                  width=65)

    label.place(x=0, y=0, height=40)

    group3 = LabelFrame(frame,
                        text="一维稳定流动一维水动力弥散问题/"
                             "一维半无限长多孔介质柱体，一端为定浓度边界",
                        font=("微软雅黑", 12, 'bold'))
    group3.place(x=30, y=50, width=850, height=520)

    group4 = LabelFrame(group3, text="参数设置", font=("微软雅黑", 12, 'bold'))
    group4.place(x=20, y=10, width=340, height=190)

    v1 = StringVar()
    v2 = StringVar()
    v3 = StringVar()
    v1.set(200)
    v2.set(10)
    v3.set(1)
    Label(group4, text="示踪剂浓度(g/l) ", font=("宋体", 10)).grid(row=0, column=0, padx=25, pady=15)
    Label(group4, text="纵向弥散系数(m2/d)").grid(row=0, column=1, padx=20)
    Entry(group4, textvariable=v1, width=15).grid(row=1, column=0, padx=15)
    Entry(group4, textvariable=v2, width=15).grid(row=1, column=1, padx=15)
    Label(group4, text="水流速度(m/d) ").grid(row=2, column=0, padx=20, pady=12)
    Entry(group4, textvariable=v3, width=15).grid(row=3, column=0, padx=20)

    # 组件“选择方案”
    group5 = LabelFrame(group3, text="选择方案", font=("微软雅黑", 12, 'bold'))
    group5.place(x=380, y=10, width=450, height=190)

    var = IntVar()
    w1 = StringVar()
    w2 = StringVar()
    w3 = StringVar()
    w4 = StringVar()
    w5 = StringVar()
    w6 = StringVar()
    w1.set(50)
    w2.set(100)
    w3.set(10)
    w4.set(50)
    w5.set(50)
    w6.set(10)

    r = Radiobutton(group5, text="方案一：固定时间，不同位置预测", variable=var, value=1)
    r.grid(row=0, column=0, columnspan=2)
    Label(group5, text="预测时间,(d) ", font=("宋体", 10)).grid(row=1, column=0, padx=20)
    Label(group5, text="最远距离,(m) ", font=("宋体", 10)).grid(row=1, column=1, padx=20)
    Label(group5, text="距离间距，(m) ", font=("宋体", 10)).grid(row=1, column=2, padx=20)
    Entry(group5, textvariable=w1, width=15).grid(row=2, column=0, padx=20, )
    Entry(group5, textvariable=w2, width=15).grid(row=2, column=1, padx=20)
    Entry(group5, textvariable=w3, width=15).grid(row=2, column=2, padx=20)
    Radiobutton(group5, text="方案二：固定位置，不同时间预测", variable=var, value=2).grid(row=3, column=0, columnspan=2)
    Label(group5, text="预测距离,(m) ", font=("宋体", 10)).grid(row=4, column=0, )
    Label(group5, text="最大时间,(d) ", font=("宋体", 10)).grid(row=4, column=1)
    Label(group5, text="时间间隔,(d) ", font=("宋体", 10)).grid(row=4, column=2)
    Entry(group5, textvariable=w4, width=15).grid(row=5, column=0)
    Entry(group5, textvariable=w5, width=15).grid(row=5, column=1)
    Entry(group5, textvariable=w6, width=15).grid(row=5, column=2)

    # 组件“预测结果”

    group6 = LabelFrame(group3, text="预测结果", font=("微软雅黑", 12, 'bold'))
    group6.place(x=20, y=220, width=810, height=220)
    t = Text(group6, width=110)

    S1 = Scrollbar(group6)
    S1.pack(side=RIGHT, fill=Y)
    t.pack(side=LEFT, fill=Y)
    S1.config(command=t.yview)
    t.config(yscrollcommand=S1.set)

    Button(group3, text="计算结果", command=Calculation, font=("微软雅黑", 12, 'bold')).place(x=120, y=450)
    Button(group3, text="图形显示", command=Drawing, font=("微软雅黑", 12, 'bold')).place(x=570, y=450)



def ct6():
    global frame
    frame.pack_forget()
    frame = Frame(root, width=900, height=800)
    frame.pack(side=LEFT)

    text = Text(frame, width=130, height=46)
    text.place(x=0, y=0)
    text.tag_config("link", font=("华文楷体", 14, 'bold'))
    text.insert(INSERT, " \n                             "
                        "               一维稳定流动二维水动力弥散问题"
                        "\n\n               瞬时注入示踪剂——平面瞬时点源:"
                        "\n\n\t\t\t\t\t", "link")

    text.image_create(INSERT, image=photo2)
    text.insert(INSERT, "\n\n              式中：x ，y ——计算点处的位置坐标；"
                        "\n\n                        t ——时间，d；"
                        "\n\n                        C(x ,y ,t)——t 时刻点 x，y 处的示踪剂质量浓度，g/L；"
                        "\n\n                        M ——承压含水层的厚度，m；"
                        "\n\n                        mM ——长度为 M 的线源瞬时注入的示踪剂质量，kg；"
                        "\n\n                        u ——水流速度，m/d；"
                        "\n\n                        ne——有效孔隙度，量纲为 1；"
                        "\n\n                        DL——纵向弥散系数，m2/d；"
                        "\n\n                        DT ——横向 y 方向的弥散系数，m2/d；"
                        "\n\n                        π ——圆周率。", "link")


def ct7():
    def Calculation():
        t.delete("1.0", END)
        x = float(v1.get())
        y = float(v2.get())
        mM = float(v3.get())
        M = float(v4.get())
        ne = float(v5.get())
        u = float(v6.get())
        DL = float(v7.get())
        DT = float(v8.get())
        x1 = float(w1.get())
        y1 = float(w2.get())
        Tmax = float(w3.get())
        dt = float(w4.get())
        t1 = float(w8.get())
        Xmin = float(w5.get())
        Xmax = float(w6.get())
        dx = float(w7.get())
        Ymin = float(w9.get())
        Ymax = float(w10.get())
        dy = float(w11.get())

        if (var.get()) == 1:
            L = list(np.arange(dt, Tmax, dt))
            t.tag_config("link2", font=("微软雅黑", 12, 'bold'), justify=LEFT)
            t.insert("insert", "固定位置，不同时间预测的结果为：\n", "link2")
            t.insert("insert", "预测点坐标：   x= " + str(x+x1) + "     y = " + str(y + y1) + '\n', "link2")
            t.insert("insert", "预测时间（d）\t\t   预测污染物浓度(g/l)\n", "link2")
            for t2 in L:
                X = []
                Y = []
                a = (mM/M)
                b = 4 * np.pi*ne*t2* (math.sqrt(DL*DT))
                c = (((x+x1)-u*t2)**2)/(4*DL*t2)
                d = ((y+y1)**2)/(4*DT*t2)
                e = 2.718281828459 **(-1*(c+d))
                C1 = (a/b)*e
                X.append(t2)
                Y.append(C1)
                t.insert("insert", '  '+str(X[0])+'\t\t  '+str(Y[0]) + '\n', "link2")

        if (var.get()) == 2:
            L1 = list(np.arange(Xmin, Xmax, dx))
            L2 = list(np.arange(Ymin, Ymax, dy))
            t.tag_config("link2", font=("微软雅黑", 12, 'bold'), justify=LEFT)
            t.insert("insert", "固定时间，不同位置预测的结果为：\n", "link2")
            t.insert("insert", "预测时间： T= " + str(t1) +  '\n', "link2")
            t.insert("insert", "  x \t\t  y \t\t\t  浓度\n", "link2")
            for x2 in L1:
                X = []
                for y2 in L2:
                    Y = []
                    Z = []
                    a = (mM / M)
                    b = 4 * np.pi * ne * t1 * (math.sqrt(DL * DT))
                    c = (((x + x2) - u * t1) ** 2) / (4 * DL * t1)
                    d = ((y + y2) ** 2) / (4 * DT * t1)
                    e = 2.718281828459 ** (-1 * (c + d))
                    C2 = (a / b) * e

                    X.append(x + x2)
                    Y.append(y + y2)
                    Z.append(C2)

                    t.insert("insert", str(X[0])+ '\t\t' + str(Y[0])+ '\t\t' + str(Z[0]) + '\n', "link2")

    def Drawing():
        t.delete("1.0", END)
        x = float(v1.get())
        y = float(v2.get())
        mM = float(v3.get())
        M = float(v4.get())
        ne = float(v5.get())
        u = float(v6.get())
        DL = float(v7.get())
        DT = float(v8.get())
        x1 = float(w1.get())
        y1 = float(w2.get())
        Tmax = float(w3.get())
        dt = float(w4.get())
        t1 = float(w8.get())
        Xmin = float(w5.get())
        Xmax = float(w6.get())
        dx = float(w7.get())
        Ymin = float(w9.get())
        Ymax = float(w10.get())
        dy = float(w11.get())

        if (var.get()) == 1:
            L = list(np.arange(0.00000000001, Tmax))
            X = []
            Y = []
            for t2 in L:
                a = (mM / M)
                b = 4 * np.pi * ne * t2 * (math.sqrt(DL * DT))
                c = (((x + x1) - u * t2) ** 2) / (4 * DL * t2)
                d = ((y + y1) ** 2) / (4 * DT * t2)
                e = 2.718281828459 ** (-1 * (c + d))
                C1 = (a / b) * e
                X.append(t2)
                Y.append(C1)


            plt.plot(X, Y, "b", linewidth=1.5)
            plt.xlim(0, Tmax)
            plt.ylim(0, max(Y))
            plt.title("点源瞬时注入，时间--浓度关系图 \nX = " + str(x+x1) + "(m) , Y = " + str(y+y1) + "(m)")
            plt.xlabel("T-时间 (d)")
            plt.ylabel("C-浓度 (g/L)")
            mpl.rcParams['font.sans-serif'] = ['SimHei']
            mpl.rcParams['axes.unicode_minus'] = False
            plt.show()

        if (var.get()) == 2:
            X = np.arange(0, Xmax)
            Y = np.arange(0, Ymax)

            def f(X, Y):
                a = (mM/ M)
                b = 4 * np.pi * ne * t1 * (np.sqrt(DL * DT))
                c = (((x + X) - u * t1) ** 2) / (4 * DL * t1)
                d = ((y + Y) ** 2) / (4 * DT * t1)
                e = 2.718281828459 ** (-1 * (c + d))
                C2 = (a / b) * e
                return C2

            X, Y = np.meshgrid(X, Y)
            plt.title("点源瞬时注入，距离--浓度关系图")
            plt.xlabel("X--距离")
            plt.ylabel("Y--距离")

            # plt.rcParams['savefig.dpi'] = 300  # 图片像素
            # plt.rcParams['figure.dpi'] = 300
            #
            # # colorslist = ['w', 'paleturquoise','aquamarine','yellow',
            # #                           'palegreen','lime','deeppink','fuchsia','darkblue','saddlebrown']
            # # colorslist = ['w','cyan','orangered','gold' ,'lime'  ,'midnightblue'  ,'dimgray','indigo','k']
            # colorslist = ['w','gold','w','gold','greenyellow','hotpink','black','blue','black','blue','black']
            # # 将颜色条命名为mylist，一共插值颜色条3000个
            # cmaps = colors.LinearSegmentedColormap.from_list('mylist', colorslist, N=10000)
            # # 画40层颜色
            # cset = plt.contourf(X, Y, f(X, Y), 1000, cmap=cmaps)
            # # 画200条线，设置字体大小为10
            # contour = plt.contour(X, Y, f(X, Y), colors='k')
            #
            # # 坐标轴的字体采用LATEX
            # plt.xlim(0, 200)
            # plt.ylim(0, 100)
            # # 显示颜色条
            # plt.colorbar(cset)
            # mpl.rcParams['font.sans-serif'] = ['SimHei']
            # mpl.rcParams['axes.unicode_minus'] = False
            # # 显示图片
            # plt.show()

            cset = plt.contourf(X, Y, f(X, Y),1000 , cmap='cubehelix_r')
            #plt.contour(X, Y, f(X, Y), 3,  cmap='cubehelix_r')
            #cset = plt.contourf(X, Y, f(X, Y),1000 , cmap='magma_r')
            #cset = plt.contourf(X, Y, f(X, Y), 1000, cmap='hot')
            # cset = plt.contourf(X, Y, f(X, Y), 1000, cmap='hot_r')

            #cset = plt.contourf(X, Y, f(X, Y), 1000, cmap='magma')

            cset = plt.contourf(X, Y, f(X, Y), 1000, cmap='Blues')
            contour = plt.contour(X, Y, f(X, Y), 10, cmap='Greys')
            plt.clabel(contour, fontsize=8, colors='k')
            plt.colorbar(cset)



            mpl.rcParams['font.sans-serif'] = ['SimHei']
            mpl.rcParams['axes.unicode_minus'] = False
            plt.show()




    global frame
    frame.pack_forget()
    frame = Frame(root, width=900, height=800)
    frame.pack(side=LEFT)

    label = Label(frame,
                  text="地下水溶质运移计算",
                  bg="black",
                  fg="white",
                  font=("华文楷体", 18, 'bold'),
                  width=65)

    label.place(x=0, y=0, height=40)

    group3 = LabelFrame(frame,
                        text="一维稳定流动二维水动力弥散问题/"
                             "瞬时注入示踪剂——平面瞬时点源",
                        font=("微软雅黑", 12, 'bold'))
    group3.place(x=30, y=50, width=850, height=520)

    # 组件“参数设置”
    group4 = LabelFrame(group3, text="参数设置", font=("微软雅黑", 12, 'bold'))
    group4.place(x=20, y=20, width=160, height=450)

    v1 = StringVar()
    v2 = StringVar()
    v3 = StringVar()
    v4 = StringVar()
    v5 = StringVar()
    v6 = StringVar()
    v7 = StringVar()
    v8 = StringVar()
    v1.set(0)
    v2.set(0)
    v3.set(1000)
    v4.set(2)
    v5.set(0.2)
    v6.set(1)
    v7.set(20)
    v8.set(10)

    Label(group4, text="污染源位置 X = ").grid(row=0, column=0, padx=20, pady=2)
    Entry(group4, textvariable=v1, width=15).grid(row=1, column=0, padx=20, pady=2)
    Label(group4, text="污染源位置 Y = ").grid(row=2, column=0, padx=20, pady=2)
    Entry(group4, textvariable=v2, width=15).grid(row=3, column=0, padx=20, pady=2)
    Label(group4, text="示踪剂质量(kg) ").grid(row=4, column=0, padx=20, pady=2)
    Entry(group4, textvariable=v3, width=15).grid(row=5, column=0, padx=20, pady=2)
    Label(group4, text="含水层厚度(m)").grid(row=6, column=0, pady=2)
    Entry(group4, textvariable=v4, width=15).grid(row=7, column=0, pady=2)
    Label(group4, text="有效孔隙度").grid(row=8, column=0, pady=2)
    Entry(group4, textvariable=v5, width=15).grid(row=9, column=0, pady=2)
    Label(group4, text="水流速度(m/d)").grid(row=10, column=0, pady=2)
    Entry(group4, textvariable=v6, width=15).grid(row=11, column=0, pady=2)
    Label(group4, text="纵向弥散系数(m2/d)").grid(row=12, column=0, pady=2)
    Entry(group4, textvariable=v7, width=15).grid(row=13, column=0, pady=2)
    Label(group4, text="横向弥散系数(m2/d)").grid(row=14, column=0, pady=2)
    Entry(group4, textvariable=v8, width=15).grid(row=15, column=0, pady=2)

    # 组件选择方案
    group5 = LabelFrame(group3, text="选择方案", font=("微软雅黑", 12, 'bold'))
    group5.place(x=220, y=10, width=600, height=220)
    var = IntVar()
    w1 = StringVar()
    w2 = StringVar()
    w3 = StringVar()
    w4 = StringVar()
    w5 = StringVar()
    w6 = StringVar()
    w7 = StringVar()
    w8 = StringVar()
    w9 = StringVar()
    w10 = StringVar()
    w11 = StringVar()
    w1.set(0)
    w2.set(0)
    w3.set(100)
    w4.set(10)
    w5.set(10)
    w6.set(200)
    w7.set(10)
    w8.set(50)
    w9.set(10)
    w10.set(100)
    w11.set(10)

    Radiobutton(group5, text="方案一：固定位置，不同时间预测", variable=var, value=1).grid(row=0, column=0, columnspan=2)
    Label(group5, text="污染源相对位置 X =", font=("宋体", 10)).grid(row=1, column=0, padx=15)
    Label(group5, text="Y = ", font=("宋体", 10)).grid(row=1, column=1, padx=15)
    Label(group5, text="最大时间(d) ", font=("宋体", 10)).grid(row=1, column=2, padx=15)
    Label(group5, text="时间间隔(d)", font=("宋体", 10)).grid(row=1, column=3, padx=15)
    Entry(group5, textvariable=w1, width=15).grid(row=2, column=0, padx=15)
    Entry(group5, textvariable=w2, width=15).grid(row=2, column=1, padx=15)
    Entry(group5, textvariable=w3, width=15).grid(row=2, column=2, padx=15)
    Entry(group5, textvariable=w4, width=15).grid(row=2, column=3, padx=15)
    Radiobutton(group5, text="方案二：固定时间，不同位置预测", variable=var, value=2).grid(row=3, column=0, columnspan=2)
    Label(group5, text="Xmin(m) ", font=("宋体", 10)).grid(row=4, column=0)
    Label(group5, text="Xmax(m) ", font=("宋体", 10)).grid(row=4, column=1)
    Label(group5, text="距离间距dx(m) ", font=("宋体", 10)).grid(row=4, column=2)
    Label(group5, text="预测时间(d) ", font=("宋体", 10)).grid(row=4, column=3)
    Entry(group5, textvariable=w5, width=15).grid(row=5, column=0)
    Entry(group5, textvariable=w6, width=15).grid(row=5, column=1)
    Entry(group5, textvariable=w7, width=15).grid(row=5, column=2)
    Entry(group5, textvariable=w8, width=15).grid(row=5, column=3)
    Label(group5, text="Ymin(m) ", font=("宋体", 10)).grid(row=6, column=0)
    Label(group5, text="Ymax(m) ", font=("宋体", 10)).grid(row=6, column=1)
    Label(group5, text="距离间距dy(m) ", font=("宋体", 10)).grid(row=6, column=2)
    Entry(group5, textvariable=w9, width=15).grid(row=7, column=0)
    Entry(group5, textvariable=w10, width=15).grid(row=7, column=1)
    Entry(group5, textvariable=w11, width=15).grid(row=7, column=2)

    # 组件预测结果
    w12 = StringVar()
    group6 = LabelFrame(group3, text="预测结果", font=("微软雅黑", 12, 'bold'))
    group6.place(x=220, y=230, width=600, height=200)
    t = Text(group6, width=82)

    S1 = Scrollbar(group6)
    S1.pack(side=RIGHT, fill=Y)
    t.pack(side=LEFT, fill=Y)
    S1.config(command=t.yview)
    t.config(yscrollcommand=S1.set)

    Button(group3, text="计算结果", command = Calculation,font=("微软雅黑", 12, 'bold')).place(x=280, y=450)

    Button(group3, text="图形显示", command = Drawing,font=("微软雅黑", 12, 'bold')).place(x=600, y=450)


def ct8():
    global frame
    frame.pack_forget()
    frame = Frame(root, width=900, height=800)
    frame.pack(side=LEFT)

    text = Text(frame, width=130, height=46)
    S1 = Scrollbar(frame)
    S1.pack(side=RIGHT, fill=Y)
    text.pack(side=LEFT, fill=Y)
    S1.config(command=text.yview)
    text.config(yscrollcommand=S1.set)

    text.tag_config("link", font=("华文楷体", 14, 'bold'))
    text.insert(INSERT, " \n                             "
                        "               一维稳定流动二维水动力弥散问题"
                        "\n\n               连续注入示踪剂——平面连续点源:"
                        "\n\n\t\t\t", "link")

    text.image_create(INSERT, image=photo3)
    text.insert(INSERT, "\n\n              式中：x ，y ——计算点处的位置坐标；"
                        "\n\n                        t ——时间，d；"
                        "\n\n                        C(x ,y ,t)——t 时刻点 x，y 处的示踪剂质量浓度，g/L；"
                        "\n\n                        M ——承压含水层的厚度，m；"
                        "\n\n                        mt——单位时间注入示踪剂的质量，kg/d；"
                        "\n\n                        u ——水流速度，m/d；"
                        "\n\n                        ne——有效孔隙度，量纲为 1；"
                        "\n\n                        DL——纵向弥散系数，m2/d；"
                        "\n\n                        Dr ——横向 y 方向的弥散系数，m2/d；"
                        "\n\n                        π ——圆周率。"
                        "\n\n                        K0(β) ——第二类零阶修正贝塞尔函数；"
                        "\n\n                        ", "link")
    text.image_create(INSERT, image=photo4)
    text.insert(INSERT, "——第一类越流系统井函数。\n\n", "link")


def ct9():
    def Calculation():
        t.delete("1.0", END)
        x = float(v1.get())
        y = float(v2.get())
        mt = float(v3.get())
        M = float(v4.get())
        ne = float(v5.get())
        u = float(v6.get())
        DL = float(v7.get())
        DT = float(v8.get())
        x1 = float(w1.get())
        y1 = float(w2.get())
        Tmax = float(w3.get())
        dt = float(w4.get())
        t1 = float(w8.get())
        Xmin = float(w5.get())
        Xmax = float(w6.get())
        dx = float(w7.get())
        Ymin = float(w9.get())
        Ymax = float(w10.get())
        dy = float(w11.get())

        if (var.get() == 1):

            t.tag_config("link2", font=("微软雅黑", 12, 'bold'), justify=LEFT)
            t.insert("insert", "固定位置，不同时间预测的结果为：\n", "link2")
            t.insert("insert", "预测点坐标：   x= " + str(x + x1) + "     y = " + str(y + y1) + '\n', "link2")
            t.insert("insert", "预测时间（d）\t\t   预测污染物浓度(g/l)\n", "link2")
            L = list(np.arange(dt, Tmax, dt))

            for t2 in L:
                X = []
                Y = []
                a = 4 * np.pi * M * ne * (math.sqrt(DL * DT))
                b = 2.718281828459 ** (((x + x1) * u) / (2 * DL))

                Batel = math.sqrt(
                    ((u ** 2) * ((x + x1) ** 2)) / (4 * (DL ** 2)) + ((u ** 2) * ((y + y1) ** 2)) / (4 * DL * DT))
                LW = (u ** 2 * t2) / (4 * DL)
                UP = np.inf
                fw = quad(lambda Y: (1 / Y) * math.exp((-1) * (Y + Batel * Batel / (4 * Y))), LW, UP)

                C = (mt / a) * b * (2 * special.kv(0, Batel) - fw[0])

                X.append(t2)
                Y.append(C)
                t.insert("insert", str(X[0]) + '\t\t' + str(Y[0])  + '\n', "link2")

        if (var.get() == 2):
            t.tag_config("link2", font=("微软雅黑", 12, 'bold'), justify=LEFT)
            t.insert("insert", "固定时间，不同位置预测的结果为：\n", "link2")
            t.insert("insert", "预测时间： T= " + str(t1) + '\n', "link2")
            t.insert("insert", "  x \t\t  y \t\t  浓度（g/l）\n", "link2")
            L1 = list(np.arange(Xmin, Xmax, dx))
            L2 = list(np.arange(Ymin, Ymax, dy))

            for x2 in L1:
                X = []
                for y2 in L2:
                    Y = []
                    Z = []
                    a = 4 * np.pi * M * ne * (math.sqrt(DL * DT))
                    b = 2.718281828459 ** (((x + x2) * u) / (2 * DL))

                    Batel = np.sqrt(
                        ((u ** 2) * ((x + x2) ** 2)) / (4 * (DL ** 2)) + ((u ** 2) * ((y + y2) ** 2)) / (4 * DL * DT))
                    LW = (u ** 2 * t1) / (4 * DL)
                    UP = np.inf
                    fw = quad(lambda Y: (1 / Y) * math.exp((-1) * (Y + Batel * Batel / (4 * Y))), LW, UP)

                    C = (mt / a) * b * (2 * special.kv(0, Batel) - fw[0])
                    X.append(x + x2)
                    Y.append(y +y2)
                    Z.append(C)


                    t.insert("insert", str(X[0]) + '\t\t' + str(Y[0]) + '\t\t' + str(Z[0]) + '\n', "link2")
                    # print(LW)
                    # print(Batel)
                    # print(special.kv(0, Batel))
                    # print(fw[0])
                    # print(b)
                    # print(mt / a)
                    # print(C)
                    # print('``````')
    def Drawing():
        x = float(v1.get())
        y = float(v2.get())
        mt = float(v3.get())
        M = float(v4.get())
        ne = float(v5.get())
        u = float(v6.get())
        DL = float(v7.get())
        DT = float(v8.get())
        x1 = float(w1.get())
        y1 = float(w2.get())
        Tmax = float(w3.get())
        dt = float(w4.get())
        t1 = float(w8.get())
        Xmin = float(w5.get())
        Xmax = float(w6.get())
        dx = float(w7.get())
        Ymin = float(w9.get())
        Ymax = float(w10.get())
        dy = float(w11.get())

        if (var.get() == 1):
            L = list(np.arange(0.00000001, Tmax, dt))
            X = []
            Y = []
            for t2 in L:
                a = 4 * np.pi * M * ne * (math.sqrt(DL * DT))
                b = 2.718281828459 ** (((x + x1) * u) / (2 * DL))

                Batel = np.sqrt(
                    ((u ** 2) * ((x + x1) ** 2)) / (4 * (DL ** 2)) + ((u ** 2) * ((y + y1) ** 2)) / (4 * DL * DT))
                LW = (u ** 2 * t2) / (4 * DL)
                UP = np.inf
                fw = quad(lambda Y: (1 / Y) * math.exp((-1) * (Y + Batel * Batel / (4 * Y))), LW, UP)

                C = (mt / a) * b * (2 * special.kv(0, Batel) - fw[0])
                X.append(t2)
                Y.append(C)
            plt.plot(X, Y, "c-.", linewidth=1.5)


            plt.title("定浓度边界，距离--浓度关系图\nX = "+str(x1) + "  Y = "+ str(y1))
            plt.xlabel("T-时间")
            plt.ylabel("C-浓度")
            mpl.rcParams['font.sans-serif'] = ['SimHei']
            mpl.rcParams['axes.unicode_minus'] = False
            plt.show()

        if (var.get() == 2):
            L1 = np.arange(Xmax)
            L2 = np.arange(Ymax)

            X = []
            Y = []
            Z = []
            for x2 in L1:
                for y2 in L2:
                    a = 4 * np.pi * M * ne * (np.sqrt(DL * DT))
                    b = 2.718281828459 ** (((x + x2) * u) / (2 * DL))
                    Batel = np.sqrt(
                        ((u ** 2) * ((x + x2) ** 2)) / (4 * (DL ** 2)) + ((u ** 2) * ((y + y2) ** 2)) / (4 * DL * DT))
                    LW = (u ** 2 * t1) / (4 * DL)
                    UP = np.inf
                    fw = quad(lambda Y: (1 / Y) * np.exp((-1) * (Y + Batel * Batel / (4 * Y))), LW, UP)
                    C = (mt / a) * b * (2 * special.kv(0, Batel) - fw[0])
                    X.append(x2)
                    Y.append(y2)
                    Z.append(C)

            x, y, z = X, Y, Z

            # 对x操作
            x = np.array(x)  # 将list变成array
            x.shape = (int(Xmax), int(Ymax))  # 重新分成3*3的array
            x = np.mat(x).T  # 变成矩阵并转置，因为array没有转置
            # 对y操作
            y = np.array(y)
            y.shape = (int(Xmax), int(Ymax))
            y = np.mat(y).T
            # 对z操作
            z = np.array(z)
            z.shape = (int(Xmax), int(Ymax))
            z = np.mat(z).T
            # 画图

            cset = plt.contourf(x,y,z, 6, cmap = 'Blues')
            contour = plt.contour(x,y,z, 10, cmap='Greys')
            plt.clabel(contour, fontsize=8, colors='k')
            plt.colorbar(cset)

            plt.xlim(0, Xmax)
            plt.ylim(0, Ymax)
            plt.title("点源持续注入，距离--浓度关系图\nT = "+ str(t1) + " 天")
            plt.xlabel("X--距离")
            plt.ylabel("Y--距离")

            mpl.rcParams['font.sans-serif'] = ['SimHei']
            mpl.rcParams['axes.unicode_minus'] = False
            plt.show()


            # X = np.arange(-(Xmax + dx), (Xmax + dx))
            # Y = np.arange(-(Ymax + dy), (Ymax + dy))
            #
            # def f(X, Y):
            #     a = 4 * np.pi * M * ne * (np.sqrt(DL * DT))
            #     b = 2.718281828459 ** (((x + X) * u) / (2 * DL))
            #     Batel = np.sqrt(
            #         ((u ** 2) * ((x + X) ** 2)) / (4 * (DL ** 2)) + ((u ** 2) * ((y + Y) ** 2)) / (4 * DL * DT))
            #     LW = (u ** 2 * t1) / (4 * DL)
            #     UP = np.inf
            #     fw = quad(lambda Y: (1 / Y) * np.exp((-1) * (Y + Batel * Batel / (4 * Y))), LW, UP)
            #     print(fw)
            #     C = (mt / a) * b * (2 * special.kv(0, Batel) - fw[0])
            #     #C = (mt / a) * b * (2 * special.kv(0, Batel) )
            #     return C
            #
            # X, Y = np.meshgrid(X, Y)
            # plt.title("点源持续注入，距离--浓度关系图")
            # plt.xlabel("X--距离")
            # plt.ylabel("Y--距离")
            # C1 = plt.contour(X, Y, f(X, Y), 20, cmap='jet')
            # plt.clabel(C1, inline=10, fontsize=8)
            # plt.colorbar()
            # mpl.rcParams['font.sans-serif'] = ['SimHei']
            # mpl.rcParams['axes.unicode_minus'] = False
            # plt.show()


    global frame
    frame.pack_forget()
    frame = Frame(root, width=900, height=800)
    frame.pack(side=LEFT)

    label = Label(frame,
                  text="地下水溶质运移计算",
                  bg="black",
                  fg="white",
                  font=("微软雅黑", 18, 'bold'),
                  width=60)

    label.place(x=0, y=0, height=40)

    group3 = LabelFrame(frame,
                        text="一维稳定流动二维水动力弥散问题/"
                             "连续注入示踪剂——平面连续点源",
                        font=("微软雅黑", 12, 'bold'))
    group3.place(x=30, y=50, width=850, height=520)

    # 组件“参数设置”
    group4 = LabelFrame(group3, text="参数设置", font=("微软雅黑", 12, 'bold'))
    group4.place(x=20, y=20, width=160, height=450)

    v1 = StringVar()
    v2 = StringVar()
    v3 = StringVar()
    v4 = StringVar()
    v5 = StringVar()
    v6 = StringVar()
    v7 = StringVar()
    v8 = StringVar()
    v1.set(0)
    v2.set(0)
    v3.set(1000)
    v4.set(2)
    v5.set(0.5)
    v6.set(1)
    v7.set(20)
    v8.set(10)

    Label(group4, text="污染源位置 X = ").grid(row=0, column=0, padx=20, pady=2)
    Entry(group4, textvariable=v1, width=15).grid(row=1, column=0, padx=20, pady=2)
    Label(group4, text="污染源位置 Y = ").grid(row=2, column=0, padx=20, pady=2)
    Entry(group4, textvariable=v2, width=15).grid(row=3, column=0, padx=20, pady=2)
    Label(group4, text="污染物注入量(kg/d) ").grid(row=4, column=0, padx=20, pady=2)
    Entry(group4, textvariable=v3, width=15).grid(row=5, column=0, padx=20, pady=2)
    Label(group4, text="含水层厚度(m)").grid(row=6, column=0, pady=2)
    Entry(group4, textvariable=v4, width=15).grid(row=7, column=0, pady=2)
    Label(group4, text="有效孔隙度").grid(row=8, column=0, pady=2)
    Entry(group4, textvariable=v5, width=15).grid(row=9, column=0, pady=2)
    Label(group4, text="水流速度(m/d)").grid(row=10, column=0, pady=2)
    Entry(group4, textvariable=v6, width=15).grid(row=11, column=0, pady=2)
    Label(group4, text="纵向弥散系数(m2/d)").grid(row=12, column=0, pady=2)
    Entry(group4, textvariable=v7, width=15).grid(row=13, column=0, pady=2)
    Label(group4, text="横向弥散系数(m2/d)").grid(row=14, column=0, pady=2)
    Entry(group4, textvariable=v8, width=15).grid(row=15, column=0, pady=2)

    # 组件选择方案
    group5 = LabelFrame(group3, text="选择方案", font=("微软雅黑", 12, 'bold'))
    group5.place(x=220, y=10, width=600, height=220)
    var = IntVar()
    w1 = StringVar()
    w2 = StringVar()
    w3 = StringVar()
    w4 = StringVar()
    w5 = StringVar()
    w6 = StringVar()
    w7 = StringVar()
    w8 = StringVar()
    w9 = StringVar()
    w10 = StringVar()
    w11 = StringVar()
    w1.set(100)
    w2.set(100)
    w3.set(100)
    w4.set(10)
    w5.set(10)
    w6.set(100)
    w7.set(10)
    w8.set(50)
    w9.set(10)
    w10.set(100)
    w11.set(10)
    Radiobutton(group5, text="方案一：固定位置，不同时间预测", variable=var, value=1).grid(row=0, column=0, columnspan=2)
    Label(group5, text="污染源相对位置 X =").grid(row=1, column=0, padx=15)
    Label(group5, text="Y = ").grid(row=1, column=1, padx=15)
    Label(group5, text="最大时间(d) ").grid(row=1, column=2, padx=15)
    Label(group5, text="时间间隔(d)").grid(row=1, column=3, padx=15)
    Entry(group5, textvariable=w1, width=15).grid(row=2, column=0, padx=15)
    Entry(group5, textvariable=w2, width=15).grid(row=2, column=1, padx=15)
    Entry(group5, textvariable=w3, width=15).grid(row=2, column=2, padx=15)
    Entry(group5, textvariable=w4, width=15).grid(row=2, column=3, padx=15)
    Radiobutton(group5, text="方案二：固定时间，不同位置预测", variable=var, value=2).grid(row=3, column=0, columnspan=2)
    Label(group5, text="Xmin(m) ").grid(row=4, column=0)
    Label(group5, text="Xmax(m) ").grid(row=4, column=1)
    Label(group5, text="距离间距dx(m) ").grid(row=4, column=2)
    Label(group5, text="预测时间(d) ").grid(row=4, column=3)
    Entry(group5, textvariable=w5, width=15).grid(row=5, column=0)
    Entry(group5, textvariable=w6, width=15).grid(row=5, column=1)
    Entry(group5, textvariable=w7, width=15).grid(row=5, column=2)
    Entry(group5, textvariable=w8, width=15).grid(row=5, column=3)
    Label(group5, text="Ymin(m) ").grid(row=6, column=0)
    Label(group5, text="Ymax(m) ", font=("宋体", 10)).grid(row=6, column=1)
    Label(group5, text="距离间距dy(m) ").grid(row=6, column=2)
    Entry(group5, textvariable=w9, width=15).grid(row=7, column=0)
    Entry(group5, textvariable=w10, width=15).grid(row=7, column=1)
    Entry(group5, textvariable=w11, width=15).grid(row=7, column=2)

    # 组件预测结果
    w12 = StringVar()
    group6 = LabelFrame(group3, text="预测结果", font=("微软雅黑", 12, 'bold'))
    group6.place(x=220, y=230, width=600, height=200)
    t = Text(group6, width=82)

    S1 = Scrollbar(group6)
    S1.pack(side=RIGHT, fill=Y)
    t.pack(side=LEFT, fill=Y)
    S1.config(command=t.yview)
    t.config(yscrollcommand=S1.set)

    Button(group3, text="计算结果", command = Calculation,font=("微软雅黑", 12, 'bold')).place(x=280, y=450)
    Button(group3, text="图形显示", command = Drawing, font=("微软雅黑", 12, 'bold')).place(x=600, y=450)


def ct10():
    global frame
    frame.pack_forget()
    frame = Frame(root, width=900, height=800)
    frame.pack(side=LEFT)

    text = Text(frame, width=130, height=46)
    text.place(x = 0, y = 0)
    text.tag_config("link", font=("华文楷体", 14, 'bold'))
    text.insert(INSERT, "\n\n        本工具为高效帮助计算地下水溶质运移而做的简易软件，"
                        "支持一维模式和二维模式，只要输入相"
                        "\n\n  关数据即可计算。"
                        "\n\n        本工具运行速度快且资源占用少，计算精度很高，符合地"
                        "下水溶质浓度预测要求。"
                        "\n\n        本工具仅供测试学习使用，不具备其他用途。"
                        "\n\n\n\n        作者：Mr. Zhang"
                        "\n\n        指导老师：钱老师"
                        "\n\n        地址：太原科技大学"
                        "\n\n        QQ：1991069432"
                        "\n\n        邮箱：1991069432@qq.com"
                        ,"link")


root = Tk( )
root.geometry('900x600')
root.colormapwindows()
root.title(" 地下水溶质运移计算")

frame = Frame(root, width=900, height=800)
frame.pack(side=LEFT)

canvas = Canvas(frame,width=900,height=800 )

image = Image.open("1.jpg")
im = ImageTk.PhotoImage(image)

canvas.create_image(350,220, image=im)
canvas.create_text(450, 180,  text='地下水溶质运移计算'   , fill='white' ,font=("华文楷体", 30, 'bold'))

canvas.pack()


menubar = Menu(root, bg = 'Red')

menubar.add_command(label="首页",command=ct)
menubar.add_command(label="简介", command=ct1)

submenu = Menu(menubar, tearoff=False)
amenu = Menu(submenu, tearoff=False)
bmenu = Menu(submenu, tearoff=False)
amenu.add_command(label="公式",command = ct2)
amenu.add_separator()
amenu.add_command(label="计算", command= ct3)
bmenu.add_command(label="公式",command = ct4)
bmenu.add_separator()
bmenu.add_command(label="计算", command= ct5)
submenu.add_cascade(label="一维瞬时注入", menu=amenu)
submenu.add_separator()
submenu.add_cascade(label="一维定浓度边界", menu=bmenu)
menubar.add_cascade(label="一维模式", menu=submenu)

asubmenu = Menu(menubar, tearoff=False)
cmenu = Menu(asubmenu, tearoff=False)
dmenu = Menu(asubmenu, tearoff=False)
cmenu.add_command(label="公式",command = ct6)
cmenu.add_separator()
cmenu.add_command(label="计算", command= ct7)
dmenu.add_command(label="公式",command = ct8)
dmenu.add_separator()
dmenu.add_command(label="计算", command= ct9)
asubmenu.add_cascade(label="二维瞬时注入", menu=cmenu)
asubmenu.add_separator()
asubmenu.add_cascade(label="二维连续注入", menu=dmenu)
menubar.add_cascade(label="二维模式", menu=asubmenu)

menubar.add_command(label="关于我们", command=ct10)

photo1 = PhotoImage(file="1.png")
photo2 = PhotoImage(file="2.png")
photo3 = PhotoImage(file="3.png")
photo4 = PhotoImage(file="4.png")
photo5 = PhotoImage(file="5.png")

root.config(menu=menubar)

mainloop()